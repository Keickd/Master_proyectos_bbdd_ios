//
//  SimpleFinanceTests.swift
//  SimpleFinanceTests
//
//  Created by Libranner Leonel Santos Espinal on 19/10/24.
//

import Testing
@testable import SimpleFinance

struct SimpleFinanceTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
